import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#reading the file 
df = pd.read_csv(r"C:\Users\2273624\Downloads\myexcel.csv")
#Processing the height column with random numbers
df['Height'] = np.random.randint(150, 181, size=len(df))

#creating visualization for employees count in each team
team_count=df['Team'].value_counts()
team_count.plot(kind='bar', title='Team counts')
plt.xlabel("Team Names")
plt.ylabel("Counts")
plt.show()

#creating visualization for companies employees percentage in each team
team_percent=team_count/len(df)*100
team_percent.plot(kind='bar', title='Team counts')
plt.xlabel("Team Names")
plt.ylabel("Percentage")
plt.show()

