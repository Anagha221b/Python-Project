import pandas as pd
import matplotlib.pyplot as plt

#reading the processed file
df=pd.read_csv(r"C:\Users\2273624\Downloads\Python Project\Processed_data.csv")

#Diving the age group and count the employees in each age group
age_group=pd.cut(df['Age'],range(20,50,5),right=False)
age_distribution=age_group.value_counts()

#Visualizing the age distributions
age_distribution.plot(kind='bar',title='Age Distribution of employees in ABC',
                     color='#a9f971')
plt.xlabel("Age_groups")
plt.ylabel("Number of employees")
plt.show()