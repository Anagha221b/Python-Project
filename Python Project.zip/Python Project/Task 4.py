import pandas as pd
import matplotlib.pyplot as plt
#this is used for formatting to non-exponential.
from matplotlib import ticker

#reading the processed file
df=pd.read_csv(r"C:\Users\2273624\Downloads\Python Project\Processed_data.csv")

#groupby the specific column for better graph visualization
highest_salary_expenditure=df.groupby(['Team','Position'])['Salary'].sum()

#To get the plot in one bar for better visualization
highest_salary_expenditure.unstack().plot(kind='bar',stacked=True,
                            title='Salary Expenditure by teams and position')
plt.legend(title='Positions',bbox_to_anchor=(1,1), loc='upper left')
plt.xlabel("Teams")
plt.ylabel("Salaries")

#formatting the exponential number for clear visualization in y axis
formatter = ticker.ScalarFormatter()
formatter.set_scientific(False)
plt.gca().yaxis.set_major_formatter(formatter)
plt.show()