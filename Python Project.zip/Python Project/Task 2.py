import pandas as pd
import matplotlib.pyplot as plt

#reading the processed file
df=pd.read_csv(r"C:\Users\2273624\Downloads\Python Project\Processed_data.csv")

#creating visualization for employees at each positions
position_count=df['Position'].value_counts()
position_count.plot(kind='barh',title='Positions in ABC', color='#1b9e77')
plt.xlabel("Number of employees")
plt.ylabel("Positions")
plt.show()