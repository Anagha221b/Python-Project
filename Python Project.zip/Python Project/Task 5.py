import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#reading the processed file
df=pd.read_csv(r"C:\Users\2273624\Downloads\Python Project\Processed_data.csv")

#correlation coefficient between 'Age' and 'Salary' columns
correlation = df[['Age', 'Salary']].corr().iloc[0, 1]
sns.scatterplot(x='Age', y='Salary', data=df)

#plotted regression line to visualize the relationship between age and salary 
sns.regplot(x='Age', y='Salary', data=df,color='#a9f971')
plt.title(f'Age vs. Salary Correlation (r={correlation:.2f})')
plt.show()